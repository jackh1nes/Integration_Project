function [H, Aineq, bineq, Aeq, beq, lb, ub] = Manual_MPC_Companion(Np, A, B, Q, R)
    [~, P, ~] = dlqr(A,B,Q,R,[]);
    n = size(A, 1);
    m = size(B, 2);
    nx_total = n * Np;
    nu_total = m * Np;
    n_total  = nx_total + nu_total;

    % Cost matrices
    Qbar = blkdiag(kron(eye(Np-1), Q), P);
    Rbar = kron(eye(Np), R);
    H    = blkdiag(Qbar, Rbar);

    Aeq  = zeros(n * Np, n_total);
    beq  = zeros(n * Np, 1);

    for i = 1:Np-1
        row_idx = (i-1)*n + 1 : i*n;
        x_i_cols   = (i-1)*n + 1 : i*n;
        x_ip1_cols = i*n     + 1 : (i+1)*n;
        u_i_cols   = nx_total + (i-1)*m + 1 : nx_total + i*m; 

        Aeq(row_idx, x_i_cols =  A;
        Aeq(row_idx, u_i_cols)  =  B;
        Aeq(row_idx, x_ip1_cols) = -eye(n);
    end

    % Initial state constraint
    Ax0_row = n*(Np-1) + 1 : n*Np;
    Aeq(Ax0_row, 1:n = eye(n);
    Aeq(Ax0_row, nx_total+1 : nx_total+m = -B;

    % Bounds
    lb = [-1e6*ones(nx_total, 1); -ones(nu_total, 1)];
    ub = [ 1e6*ones(nx_total, 1);  ones(nu_total, 1)];

    Aineq = [];
    bineq = [];
end




